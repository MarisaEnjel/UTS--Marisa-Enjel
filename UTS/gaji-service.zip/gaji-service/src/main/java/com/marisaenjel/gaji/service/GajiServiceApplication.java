package com.marisaenjel.gaji.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GajiServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GajiServiceApplication.class, args);
	}

}
